# main.py

import os
import threading
import nest_asyncio # pip install nest_asyncio, 2개 루프 중첩해서 실행(tkinter,gradio)
from inoutput_tkinter import *
from inoutput_gradio import *
from soundimage import *

def main(): # 직접 제작
    # tkinter와 gradio 동시에 실행하도록 설정
    nest_asyncio.apply()

    # tt.txt 초기화
    try:
        desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')
        text_path = os.path.join(desktop_path, 'tt.txt')
        with open(text_path, 'w', encoding='utf-8') as f:
            f.write('')
    except:
        pass
    
    # 시작 시 소리 내줌
    si.play_start_sound()

    # Gradio 실행을 백그라운드 쓰레드로
    threading.Thread(target=launch_gradio, daemon=True).start()

    # Tkinter는 반드시 메인 스레드에서 실행
    start_tkinter()

# 실행
if __name__=='__main__':
    main()