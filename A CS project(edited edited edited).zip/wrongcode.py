# wrongcode.py

import importlib
import os
import site
import ast
import nbformat # pip install nbformat, Notebook 다룰 때 이용
from nbclient import NotebookClient # pip install nbclient, jupyter Notebook 실행 및 결과 반환
from nbclient.exceptions import CellExecutionError
from soundimage import *

# is_stdlib_module,is_pypi_module 는 모듈이 실행 가능한지(사용자가 만들었는데 안나온 경우 고려) 알려주는 함수
def is_stdlib_module(module_name): # by gpt
    try:
        # import 가능한지 확인
        spec = importlib.util.find_spec(module_name)
        if spec is None or spec.origin is None:
            return False
        
        # 경로가 없으면 built-in (예: math, sys 등)
        if spec.origin == 'built-in':
            return True
        
        # 표준 라이브러리 경로 확인
        stdlib_path = os.path.abspath(os.path.dirname(os.__file__))  # ex: /usr/lib/python3.10/
        module_path = os.path.abspath(spec.origin)
        return module_path.startswith(stdlib_path)
    
    except Exception:
        return False

def is_pypi_module(module_name): # by gpt
    try:
        # 모듈 스펙 가져오기
        spec = importlib.util.find_spec(module_name)

        # import 자체가 불가능한 경우
        if spec is None or spec.origin is None:
            return False 

        # 모듈 경로
        module_path = os.path.abspath(spec.origin)
        site_paths = site.getsitepackages() + [site.getusersitepackages()]

        # PyPI 설치 경로 내부에 있는지 확인
        return any(module_path.startswith(os.path.abspath(site_path)) for site_path in site_paths)
    except Exception as e:
        return False

# google.colab 등 Colab에서만 작동하는 파일이나, ipynb 파일에서만 작동하는 magic명령어가 존재하는지 판단하는 함수
def check_module(string): # 직접 제작
    # 일반적 파이썬 환경에서 실행 불가능한 것들
    not_available=['google','%','%%']
    for word in not_available:
        if word in string:
            return False
    return True

# 주석을 제거해서 코드가 같은지 확인할 때 정확도를 높이는 함수
def del_pound(string): # 직접 제작
    if '#' in string:
        idx_an=string.find('#')
        return string[:idx_an]
    else:
        return string

# Cell에서 import 된 모듈들을 모아서 반환
def extract_imports(source_code: str): # by gpt
    try:
        # 코드를 Tree형태로 재해석하여서 분석이 용이하게 해줌
        tree = ast.parse(source_code)
    except SyntaxError:
        return "", []

    lines = source_code.splitlines()
    import_lines = []
    # import되었지만 사용 불가능한 모듈들 모음
    un_imports = []

    for node in ast.walk(tree):
        # import lib 형태로 불러와진 경우
        if isinstance(node, ast.Import):
            for alias in node.names:
                modname = alias.name.split('.')[0]
                asname = alias.asname or alias.name
                asname=asname if asname else ''
                # import되었지만 사용 불가능한 모듈 판단
                if is_pypi_module(modname) or is_stdlib_module(modname):
                    import_lines.append(lines[node.lineno - 1].strip())
                else:
                    un_imports.append((alias.name, asname))

        # from lib import x 형태로 불러와진 경우
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                modname = node.module.split('.')[0]
                for alias in node.names:
                    full_name = f"{node.module}.{alias.name}"
                    asname = alias.asname or alias.name
                    asname=asname if asname else ''
                # import되었지만 사용 불가능한 모듈 판단
                if is_pypi_module(modname) or is_stdlib_module(modname):
                    import_lines.append(lines[node.lineno - 1].strip())
                else:
                    un_imports.append((full_name, asname))

    return '\n'.join(import_lines), un_imports

# Cell에서 함수들을 모두 추출해주는 함수
def extract_functions(source_code:str): # gpt가 만든 extract_imports 변형
    func_dict={}

    try:
        # 코드를 Tree형태로 재해석하여서 분석이 용이하게 해줌
        tree=ast.parse(source_code)
    except SyntaxError:
        # 파싱 실패 시 빈 dict 반환
        return func_dict

    # 소스 코드를 줄 단위 리스트로 준비
    lines=source_code.splitlines()

    for node in tree.body:
        # ast.FunctionDef가 함수의 정의 부분
        if isinstance(node,ast.FunctionDef):
            # 함수가 차지하는 줄 범위 구하기
            start=node.lineno-1
            end=node.end_lineno
            
            # 함수 정의 코드 줄만 슬라이싱
            func_lines=[]
            for line in lines[start:end]:
                func_lines.append(del_pound(line))
            func_code = '\n'.join(func_lines)

            func_dict[node.name]=func_code

    return func_dict

# Cell에서 등장하는 변수들을 모두 추출하여 반환하는 함수
def extract_variable_definitions(source_code: str): # gpt가 만든 extract_imports 변형
    try:
        # 코드를 Tree형태로 재해석하여서 분석이 용이하게 해줌
        tree=ast.parse(source_code)
    except SyntaxError:
        return {}

    # 코드를 줄 단위 리스트로 받아옴
    lines=source_code.splitlines()
    var_defs={}

    for node in ast.walk(tree):
        # 변수가 정의되는 부분 판단
        if isinstance(node,ast.Assign):
            line=lines[node.lineno-1].strip()
            targets=node.targets
            for target in targets:
                # 변수의 종류에 따라 이름과 정의 부분을 저장
                if isinstance(target,ast.Name):
                    var_defs[target.id]=line
                elif isinstance(target,ast.Tuple):
                    for elt in target.elts:
                        if isinstance(elt,ast.Name):
                            var_defs[elt.id]=line

    return var_defs

# Colab이 source code를 문자열 형태나 리스트 형태 두가지 지원하므로 이를 고려하여 두 코드를 합쳐주는 함수
def concat_sources(src1, src2): # by gpt
    # 둘 다 리스트로 변환 후 합쳐서 리턴
    def to_list(src):
        if isinstance(src, str):
            # 빈 문자열이면 빈 리스트로 처리
            return [] if src.strip() == '' else [line + '\n' for line in src.splitlines()]
        elif isinstance(src, list):
            # 이미 리스트면 그대로 리턴, 단 각 줄에 \n 없으면 붙이기
            return [line if line.endswith('\n') else line + '\n' for line in src]
        else:
            sound()
            raise TypeError(f"Unsupported source type: {type(src)}")

    list1 = to_list(src1)
    list2 = to_list(src2)
    return list1 + list2

# 파일을 입력받아서 에러가 나는 부분을 확인해주는 함수
def find_error(ipynb_path): # 직접 제작
    just_errors='' # 그냥 에러
    errors_but_ok='' # 에러 났지만, 문제 설명이나 주석에 'Error' 가 있는 경우
    module_not_found=[] # 사용 불가한 모듈
    ok_to_make_error=False # 에러를 만들어도 되는 경우(errors_but_ok와 연관)
    needed_libs='' # 이전 Cell에서 사용했지만, 다음 Cell에도 필요한 모듈
    needed_funcs={} # 이전 Cell에서 사용했지만, 다음 Cell에도 필요한 함수
    needed_varis={} # 이전 Cell에서 사용했지만, 다음 Cell에도 필요한 변수들
    need_inputs='' # input()이 필요해서 실행 가능 여부를 판단할 수 없는 Cell
    # ipynb 파일 열고 nbformat을 이용해서 실행 준비
    with open(ipynb_path, 'r', encoding='utf-8') as f:
        nb=nbformat.read(f, as_version=4)

    # Cell을 단위로 받아오고 인덱스 번호도 함께 받아옴
    for i, cell in enumerate(nb.cells):
        # Cell 중 문제 설명이 있는 부분에서 'Error'글자를 찾고, 'code'면 뒤의 과정을 실행
        if cell.cell_type != 'code':
            if cell.cell_type=='markdown':
                if 'Error' in cell['source']:
                    ok_to_make_error=True
            continue
        
        # 모듈이 없어서 실행이 불가능하면 넘김
        if not check_module(cell['source']):
            continue
        
        # input이 필요한 경우를 모아서 저장
        if 'input' in cell['source']:
            need_inputs+='\n'+f'Cell {i+1} input이 필요함'
            continue
        
        # Cell에 현재 존재하는 함수 저장
        try:
            in_cell_funcs=extract_functions(cell['source'])
        except TypeError:
            in_cell_funcs=extract_functions('\n'.join(cell['source']))
        
        # ipynb 파일에 나온 전체 함수에 현재 Cell의 함수 추가
        try:
            needed_funcs.update(in_cell_funcs)
        except: pass

        # Cell에 현재 존재하는 변수 저장
        try:
            in_cell_varis=extract_variable_definitions(cell['source'])
        except TypeError:
            in_cell_varis=extract_variable_definitions('\n'.join(cell['source']))
        
        # ipynb 파일에 나온 전체 함수에 현재 Cell의 변수 추가
        try:
            needed_varis.update(in_cell_varis)
        except: pass

        # 필요한 모듈을 받아와서 사용가능한 것과 그렇지 않은 것을 나누어서 저장
        result = extract_imports(cell['source'])
        add_libs, un_imports = result if isinstance(result, tuple) and len(result) == 2 else ("", [])
        needed_libs+='\n'+add_libs
        module_not_found+=un_imports

        # 사용 불가능한 모듈의 이름이나 별칭이 Cell에 들어가 있는 경우를 거름
        tmp=False
        for names in module_not_found:
            if names[0] in cell['source']:
                idx=cell['source'].find(names[0]) # 모듈 이름
                if cell['source'][idx+len(names[0])]=='.':
                    tmp=True
                    break
            if names[1] in cell['source']: # 모듈 별칭
                idx=cell['source'].find(names[1])
                if cell['source'][idx+len(names[1])]=='.':
                    tmp=True
                    break

        if tmp:
            continue

        # 주석으로 'Error'가 명시되어 있으면 에러가 나도 되는 것으로 간주하고 넘김
        tmp=False
        for line in cell['source'].split('\n'):
            if '#' in line and 'Error' in line:
                tmp=True
                break

        if tmp:
            ok_to_make_error=True
        
        # 함수가 사용되면 저장한 이전 Cell의 함수를 추가해줌
        for func_name,func_content in needed_funcs.items():
            if func_name in in_cell_funcs:
                continue
            else:
                if func_name in cell['source']:
                    cell['source']=''.join(concat_sources(func_content,cell['source']))

        # 이전 Cell에서 사용한 변수를 현재 Cell 과 비교 대조하여 추가해줌
        for vari_name,vari_content in needed_varis.items():
            if vari_name in in_cell_varis:
                continue
            if vari_name in cell['source']:
                cell['source']=''.join(concat_sources(vari_content,cell['source']))

        # 필요한 모듈들을 코드의 앞에 추가해줌
        cell['source']=''.join(concat_sources(needed_libs,cell['source']))

        # cell을 받아와서 실행할 준비를 마침
        single_cell_nb = nbformat.v4.new_notebook(cells=[cell])
        try:
            # client로 Notebook의 주어진 Cell을 실행함
            client = NotebookClient(single_cell_nb, timeout=20, kernel_name='python3')
            client.execute()
        except CellExecutionError as e: # 오류가 나면 오류가 나도 되는 경우와 아닌 경우를 나눠서 에러 메시지 저장
            if not ok_to_make_error:
                just_errors+='\n'+f'Cell {i+1} 실패: {e.ename} - {e.evalue}'
            else:
                errors_but_ok+='\n'+f'Cell {i+1} 에러명 이거 맞지?: {e.ename} - {e.evalue}'
                ok_to_make_error=False

    # 사용 불가능한 모듈의 list를 문자열로 변환
    if module_not_found:
        mo='\n'.join([f'모듈:{tup[0]} 별칭:{tup[1]}' for tup in module_not_found])
    else:
        mo='해당사항 없음'

    return just_errors, errors_but_ok, mo, need_inputs # 왼쪽부터 그냥 에러, 에러가 나도 되는 부분, 사용 불가능한 모듈, input이 필요해서 판단 불가