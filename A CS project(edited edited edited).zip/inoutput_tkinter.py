# inoutput_tkinter.py

import gradio as gr # pip install gradio, gui 생성
import os
import json
import tkinter as tk
import webbrowser
import threading
import socket
import time
import logging
from inoutput_gradio import *

logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")

# gradio의 특정한 주소를 알려줌
PORT = 7861
gradio_url = f"http://127.0.0.1:{PORT}"

# gradio가 열렸는지 반환하는 함수
def wait_for_port(port, timeout=10): # by gpt
    start = time.time()
    logging.debug("Gradio 서버 연결 확인 시작...")
    while time.time() - start < timeout:
        # gradio를 특정한 url로 열어줌
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                logging.info("Gradio 서버 연결 성공.")
                return True
        except OSError:
            time.sleep(0.5)
    logging.error("Gradio 서버 연결 실패.")
    return False

# tkinter 창을 띄워주는 함수
def start_tkinter(): # 직접 제작
    logging.debug("Tkinter UI 실행 시작")
    # tkinter로 띄울 창의 정보
    root = tk.Tk()
    root.title("Gradio Launcher")
    root.geometry("400x160")
    root.attributes('-topmost', True)

    label = tk.Label(root, text="Launching Gradio...")
    label.pack(pady=10)

    link_label = tk.Label(root, text="(Waiting for URL...)", fg="gray", wraplength=380)
    link_label.pack(pady=5)

    button = tk.Button(root, text="Gradio 페이지로 이동하기", state="disabled")
    button.pack(pady=10)

    # gradio 서버가 실행될 때 까지 기다려주는 함수
    def wait_and_activate():
        logging.debug("Gradio 서버가 열렸는지 확인 중...")
        # gradio 서버가 열렸는지 판단
        if wait_for_port(PORT, timeout=10):
            root.after(0, lambda: [
                label.config(text="Gradio 서버가 실행되었습니다!"),
                link_label.config(text=gradio_url, fg="blue"),
                button.config(state="normal", command=lambda: webbrowser.open(gradio_url))
            ])
        else:
            root.after(0, lambda: label.config(text="Gradio 실행 실패. 포트를 열 수 없습니다.", fg="red"))

    threading.Thread(target=wait_and_activate, daemon=True).start()
    root.mainloop()

# 실행
if __name__ == "__main__":
    logging.debug("Gradio와 Tkinter 실행 시작")
    threading.Thread(target=launch_gradio, daemon=True).start()
    start_tkinter()
