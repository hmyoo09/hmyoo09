# soundimage.py

from playsound import playsound # pip install playsound, 소리 재생용
import datetime
import pyautogui # pip install pyauto gui, 캡쳐용

# 시작시 fan 돌아가는 소리로 시작하는 것을 나타내줌
def play_start_sound(): # 직접 제작
    try:
        playsound("efan.wav")  # 시작 알림 사운드
    except Exception as e:
        print(f"알림음 재생 실패: {e}")

# 에러 발생시에 경고음 나게 해줌
def sound(): # 직접 제작
    try:
        playsound("beep-03.wav")
    except Exception as audio_err:
        print(f"소리 재생 실패: {audio_err}")

# 화면 캡쳐를 자동으로 실행해주는 코드   
def capture_screen_to_file(): # 직접 제작
    try:
        # 현재 시간을 바탕으로 캡쳐 화면을 저장
        timestamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        screenshot_path=f"./gradio_live_capture_{timestamp}.png"

        screenshot=pyautogui.screenshot()
        screenshot.save(screenshot_path)

        print(f"화면 캡처 완료: {screenshot_path}")
        return f"화면 캡처 완료! 저장 위치: {screenshot_path}"
    except Exception as e:
        print(f"[캡처 실패] {e}")
        return f"캡처 실패: {e}"