# inoutput_gradio.py

import gradio as gr # pip install gradio, gui 생성
import os
import json
import logging
from emptycell import *
from wrongcode import *
import soundimage as si

logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")

# gradio를 이용한 UI 생성하는 코드
def show_UI(file): # 직접 제작
    if file is None:
        logging.error("파일이 업로드되지 않았습니다.")
        si.sound()
        raise gr.Error("파일이 존재하지 않습니다.")
    try:
        # 코랩 파일을 받아옴
        file_path=file.name
        file_size=os.path.getsize(file_path)
        logging.info(f"업로드된 파일 경로: {file_path}, 크기: {file_size} bytes")

        # 코랩 파일을 json 형식으로 열어줌
        with open(file_path,'r',encoding='utf-8') as f:
            notebook_data=json.load(f)

        # json 파일을 text 받아옴
        json_as_text=json.dumps(notebook_data,indent=2,ensure_ascii=False)

        desktop_path=os.path.join(os.path.expanduser('~'),'Desktop')
        output_path=os.path.join(desktop_path,'tt.txt')
        
        # emptycell.py에 필요한 tt.txt파일 만들어줌
        with open(output_path,'w',encoding='utf-8') as f:
            f.write(json_as_text)

        # find_error 함수로 UI에 나타낼 정보 받아옴
        errors,errors_but_ok,module_errors,need_inputs=find_error(file_path)

        # find_empty_space 함수로 누락된 부분을 반환해줌
        todo_text=find_empty_space(output_path)

        # tt.txt가 생성되면 이것을 알려줌
        info_str=f"파일명: {file_path}\n크기: {file_size} bytes\n\n"+f"tt.txt가 바탕화면에 저장되었습니다:\n{output_path}"
        logging.info(f"파일 처리 완료: {file_path}")
        return info_str,todo_text,errors,errors_but_ok,module_errors,need_inputs
    except Exception as e:
        logging.error(f"파일 처리 중 오류 발생: {e}")
        raise gr.Error(f"파일 처리 중 오류 발생: {e}")

# 만든 gradio UI를 화면에 띄워주는 코드
def launch_gradio(): # 직접 제작
    logging.debug("Gradio UI 시작")
    with gr.Blocks() as iface:
        gr.Markdown("# 코랩 암살 피하기!")

        file_input=gr.File(label="ipynb 파일 업로드",file_types=['.ipynb']) # ipynb를 받아오는 구역
        output_text=gr.Textbox(label='파일 경로와 크기',interactive=False) # 파일 경로와 크기 나타내는 구역
        finding=gr.Textbox(label='고칠 부분',interactive=False) # 에러난 부분을 알려주는 구역
        errors=gr.Textbox(label='에러난 부분',interactive=False) # 에러난 부분을 알려주는 구역
        errors_but_ok=gr.Textbox(label='에러나도 되는 부분',interactive=False) # 에러가 나도 되지만 한번 확인해봐야할 부분을 띄워주는 구역
        module_errors=gr.Textbox(label='모듈을 못잧겠음',interactive=False) # 모듈을 못찾음(사용자 정의 모듈)을 알려주는 구역
        need_inputs=gr.Textbox(label='이건 직접 입력해서 테스트 ㄱㄱ',interactive=False) # input이 필요해서 직접 실행해보아야 하는 부분을 알려주는 구역

        file_input.change(
            fn=show_UI,
            inputs=file_input,
            outputs=[output_text,finding, errors,errors_but_ok,module_errors,need_inputs]
        )
        
        # 캡쳐를 도와주는 도구
        capture_btn=gr.Button("현재 브라우저 화면 캡처하기")
        capture_result=gr.Textbox(label="캡처 결과",interactive=False)
        capture_btn.click(fn=si.capture_screen_to_file,outputs=capture_result)
        
        # gradio를 특정 서버로 열어줌
        iface.launch(server_name="127.0.0.1",server_port=7861)
