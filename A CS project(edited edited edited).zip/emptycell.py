# emptycell.py

from soundimage import *

# tt.txt 파일을 받아와서 처리함
def find_empty_space(text_path): # 직접 제작
    # 질문에 들어가는 필수 단어
    ToDoWords = ['#code', '설명', '아래에 코드 작성']
    ToDoList = []

    try:
        # tt.txt 파일 열기
        with open(text_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        sound()
        return "text파일이 정상적으로 만들어지지 않았습니다."

    # 줄대로 받아와서 ToDoWords에 있는 단어가 들어가면 반환
    for line in lines:
        if any(word in line for word in ToDoWords):
            ToDoList.append(line.strip())

    # 리스트를 문자열로 변환해서 return 
    if len(ToDoList)!=0:
        return '\n'.join([f"{i+1}. {ToDoList[i]}" for i in range(len(ToDoList))])
    else:
        return '고칠 부분이 없습니다.'
