from playsound import playsound

def play_start_sound():
    try:
        playsound("efan.wav")  # 🎵 시작 알림 사운드
    except Exception as e:
        print(f"알림음 재생 실패: {e}")


def sound():
    try:
        playsound("beep-03.wav")
    except Exception as audio_err:
        print(f"소리 재생 실패: {audio_err}")